Halo Gaes, bertemu lagi dengan aing 
Script ini tampilan V2 versi LOCK COUNTRY ya gaes, jadi jangan diedit nama gue kontol



 ______________________________________________
|                                              |
|            CLOUD HOSTING LIVE                |
|      Script Phising 18+ Lock Country         |
|         www.cloudhostinglive.com             |
|               2020 © G-Code                  |
|______________________________________________|