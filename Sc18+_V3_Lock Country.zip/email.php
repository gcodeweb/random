<?php
$gifan = 'gifanpb@gmail.com'; //Masukin email kamu disini
?>